# My Watch Tracker — Online APK Builder

This project wraps your `index.html` in an Android WebView app. You do not need Android Studio on your computer. GitHub Actions builds the APK in the cloud.

## Build the APK
1. Create/sign in to a GitHub account.
2. Create a **new public repository** named `MyWatchTracker` (public makes Actions/artifact access simpler).
3. Upload the contents of this ZIP into the repository root (upload the folders and files inside this folder, not the outer folder itself).
4. Open the repository's **Actions** tab and enable Actions if GitHub asks.
5. Select **Build My Watch Tracker APK** on the left.
6. Click **Run workflow** and confirm.
7. Wait for the run to finish with a green check.
8. Open that run, scroll to **Artifacts**, and download `My-Watch-Tracker-APK`.
9. Extract the downloaded ZIP; inside is `app-debug.apk`.
10. Transfer `app-debug.apk` to your Android phone and tap it to install. If Android asks, allow your file manager to install apps from this source.

## Notes
- This is a debug APK for personal testing/installation.
- The app bundles your HTML locally and enables JavaScript and DOM storage for the watchlist.
- Uninstalling the app or clearing its storage may erase the saved watchlist.
